//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package game;

import java.util.Random;
import java.util.Vector;

public class Cards {
    static final long serialVersionUID = 1L;
    private String[] suits = new String[]{"hearts", "diamonds", "spades", "clubs"};
    private String[] names = new String[]{"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
    private Vector cards = new Vector();

    Cards() {
        this.init();
    }

    public void init() {
        this.cards.clear();

        for(int i = 0; i < 4; ++i) {
            for(int j = 0; j < 13; ++j) {
                this.cards.add(new Card(this.suits[i], this.names[j], j >= 10 ? 10 : j + 1));
            }
        }

    }

    public Card deal() {
        Random cardIndexRandom = new Random();
        int cardIndex = cardIndexRandom.nextInt(this.cards.size() - 1);
        Card tempCard = (Card)this.cards.elementAt(cardIndex);
        this.cards.remove(cardIndex);
        return tempCard;
    }

    public Vector getCards() {
        return this.cards;
    }
}
