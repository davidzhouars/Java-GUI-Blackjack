//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package game;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;

public class User {
    static final long serialVersionUID = 1L;
    private String name;
    private String ico;
    private int money;
    private static String userInfomationFile = "config\\userInformation.xml";

    User() {
    }

    User(String n, int m, String i) {
        this.name = n;
        this.money = m;
        this.ico = i;
    }

    public void init(String n) {
        this.name = n;
        this.money = this.readUserMoney();
        this.ico = this.readUserIco();
    }

    private Document creatDoc() {
        try {
            File f = new File(userInfomationFile);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(f);
            return doc;
        } catch (Exception var5) {
            System.out.println("ReadError");
            return null;
        }
    }

    public void writeDoc(Document doc) {
        TransformerFactory tFactory = TransformerFactory.newInstance();

        try {
            Transformer transformer = tFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(userInfomationFile));
            transformer.transform(source, result);
        } catch (Exception var6) {
            System.out.println("Error");
        }

    }

    private int readUserMoney() {
        return Integer.parseInt(this.getUserNode().getNextSibling().getFirstChild().getNodeValue());
    }

    private String readUserIco() {
        return this.getUserNode().getNextSibling().getNextSibling().getFirstChild().getNodeValue();
    }

    public String getUserName() {
        return this.name;
    }

    public int getUserMoney() {
        return this.money;
    }

    public String getUserIco() {
        return this.ico;
    }

    public void setUserName(String n) {
        this.name = n;
    }

    public void setUserMoney(int m) {
        this.money = m;
    }

    public void setUserIco(String i) {
        this.ico = i;
    }

    public void addUser() {
        Document XMLDocument = this.creatDoc();
        Element nameNode = XMLDocument.createElement("name");
        nameNode.appendChild(XMLDocument.createTextNode(this.name));
        Element moneyNode = XMLDocument.createElement("money");
        moneyNode.appendChild(XMLDocument.createTextNode(String.valueOf(this.money)));
        Element icoNode = XMLDocument.createElement("ico");
        icoNode.appendChild(XMLDocument.createTextNode(this.ico));
        Element userNode = XMLDocument.createElement("user");
        userNode.appendChild(nameNode);
        userNode.appendChild(moneyNode);
        userNode.appendChild(icoNode);
        XMLDocument.getDocumentElement().appendChild(userNode);
        this.writeDoc(XMLDocument);
    }

    public boolean isUser(String n) {
        return this.getUserNode() != null;
    }

    public Node getUserNode() {
        Document XMLDocument = this.creatDoc();
        NodeList userList = XMLDocument.getElementsByTagName("user");

        for(int i = 0; i < userList.getLength(); ++i) {
            if (this.name.equals(XMLDocument.getElementsByTagName("name").item(i).getFirstChild().getNodeValue())) {
                Node tempN = XMLDocument.getElementsByTagName("name").item(i);
                return tempN;
            }
        }

        return null;
    }

    public void removeUser() {
        Document XMLDocument = this.creatDoc();
        XMLDocument.getDocumentElement().removeChild(this.getUserNode());
        this.writeDoc(XMLDocument);
    }

    public void save() {
        Document XMLDocument = this.creatDoc();
        NodeList userList = XMLDocument.getElementsByTagName("user");

        for(int i = 0; i < userList.getLength(); ++i) {
            if (this.name.equals(XMLDocument.getElementsByTagName("name").item(i).getFirstChild().getNodeValue())) {
                Node tempN = XMLDocument.getElementsByTagName("name").item(i);
                tempN.getNextSibling().getFirstChild().setNodeValue(String.valueOf(this.money));
                tempN.getNextSibling().getNextSibling().getFirstChild().setNodeValue(this.ico);
            }
        }

        this.writeDoc(XMLDocument);
        this.init(this.name);
    }
}
