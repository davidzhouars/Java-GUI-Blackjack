//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package game;

import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.util.Vector;

public class GameMain extends JFrame {
    static final long serialVersionUID = 1L;
    private Cards gameCards = new Cards();
    private Vector userCards = new Vector();
    private Vector computerCards = new Vector();
    private static String imageFile = "src/images/";
    private int userCardsValue = 0;
    private int computerCardsValue = 0;
    private int gameMoney = 0;
    private JPanel computerCardsPanel = new JPanel();
    private JPanel userCardsPanel = new JPanel();
    private JPanel centerPanel = new JPanel();
    private AudioStream as;

    GameMain() {
        this.setSize(900, 700);
        //Font fonts = new Font("???", 0, 12);
        //this.setFont(fonts);
        this.setTitle("Blackjack");
        this.getContentPane().setLayout(new BorderLayout());
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int left = (screen.width - this.getWidth()) / 2;
        int top = (screen.height - this.getHeight()) / 2;
        this.setLocation(left, top);
    }

    public Cards getGameCards() {
        return this.gameCards;
    }

    public Vector getUserCards() {
        return this.userCards;
    }

    public Vector getComputerCards() {
        return this.computerCards;
    }

    public void gameStart() {
        this.gameCards.init();
        this.userCards.clear();
        this.computerCards.clear();

        for(int i = 0; i < 5; ++i) {
            this.countCardsValue(0);
            if (this.getCardsValue(0) < 16) {
                this.addCard(0);
            }
        }

        this.addCard(1);
        this.addCard(1);
    }

    public void addCard(int u) {
        if (u == 0) {
            this.computerCards.add(this.gameCards.deal());
        }

        if (u == 1) {
            this.userCards.add(this.gameCards.deal());
        }

    }

    public void countCardsValue(int u) {
        int Anumber = 0;
        int i;
        if (u == 0) {
            this.computerCardsValue = 0;
            if (this.computerCards.size() > 0) {
                for(i = 0; i < this.computerCards.size(); ++i) {
                    if (((Card)this.computerCards.elementAt(i)).getName() == "A") {
                        ++Anumber;
                    } else {
                        this.computerCardsValue += ((Card)this.computerCards.elementAt(i)).getValue();
                    }
                }

                if (Anumber > 0) {
                    if (this.computerCardsValue + 11 + Anumber - 1 <= 21) {
                        this.computerCardsValue = this.computerCardsValue + Anumber - 1 + 11;
                    } else {
                        this.computerCardsValue += Anumber;
                    }
                }
            }
        }

        if (u == 1) {
            this.userCardsValue = 0;
            if (this.userCards.size() > 0) {
                for(i = 0; i < this.userCards.size(); ++i) {
                    if (((Card)this.userCards.elementAt(i)).getName() == "A") {
                        ++Anumber;
                    } else {
                        this.userCardsValue += ((Card)this.userCards.elementAt(i)).getValue();
                    }
                }

                if (Anumber > 0) {
                    if (this.userCardsValue + 11 + Anumber - 1 <= 21) {
                        this.userCardsValue = this.userCardsValue + Anumber - 1 + 11;
                    } else {
                        this.userCardsValue += Anumber;
                    }
                }
            }
        }

    }

    public int getCardsValue(int u) {
        if (u == 0) {
            return this.computerCardsValue;
        } else {
            return u == 1 ? this.userCardsValue : 0;
        }
    }

    public JPanel getComputerCardsPanel(boolean o) {
        this.displayComputerCards(o);
        return this.computerCardsPanel;
    }

    public JPanel getUserCardsPanel() {
        this.displayUserCards();
        return this.userCardsPanel;
    }

    public JPanel getCenterPanel() {
        return this.centerPanel;
    }

    public void setGameMoney(int v) {
        this.gameMoney = v;
    }

    public int getGameMoney() {
        return this.gameMoney;
    }

    public void displayComputerCards(boolean o) {
        int i;
        JLabel newLabel;
        if (o) {
            for(i = 0; i < this.computerCards.size(); ++i) {
                newLabel = new JLabel("", new ImageIcon(imageFile + ((Card)this.computerCards.elementAt(i)).getIco()), 0);
                newLabel.setBounds(70 + 130 * i, 20, 130, 180);
                this.computerCardsPanel.add(newLabel);
            }
        } else {
            for(i = 0; i < 5; ++i) {
                newLabel = new JLabel("", new ImageIcon(imageFile + "backSide.png"), 0);
                newLabel.setBounds(70 + 130 * i, 20, 130, 180);
                this.computerCardsPanel.add(newLabel);
            }
        }

        this.computerCardsPanel.setBounds(70, 20, 800, 180);
    }

    public void displayUserCards() {
        for(int i = 0; i < this.userCards.size(); ++i) {
            JLabel newLabel = new JLabel("", new ImageIcon(imageFile + ((Card)this.userCards.elementAt(i)).getIco()), 0);
            newLabel.setBounds(100 + 135 * i, 400, 130, 180);
            this.userCardsPanel.add(newLabel);
        }

        this.userCardsPanel.setBounds(100, 400, 800, 180);
    }

    public void soundPlay() {
        try {
            FileInputStream fileau = new FileInputStream("images/sound1.mid");
            this.as = new AudioStream(fileau);
            AudioPlayer.player.start(this.as);
        } catch (Exception var2) {
            System.out.println("error!");
        }

    }

    public void soundStop() {
        AudioPlayer.player.stop(this.as);
    }

    public static void main(String[] args) {
        final GameMain game = new GameMain();
        final User gameUser = new User();
        //gameUser.init("feifei");
        final User computerUser = new User();
        //computerUser.init("computer");
        game.getContentPane().add(game.getCenterPanel(), "Center");
        game.getCenterPanel().setLayout((LayoutManager)null);
        game.gameStart();
        JMenuBar menuBar = new JMenuBar();
        JMenu system = new JMenu("Game");
        JMenu user = new JMenu("User");
        JMenu set = new JMenu("Settings");
        JMenu help = new JMenu("Help");
        JMenuItem quit = new JMenuItem("Quit");
        JMenuItem setUser = new JMenuItem("User Settings");
        final JMenuItem musicOn = new JMenuItem("Music On");
        final JMenuItem musicOff = new JMenuItem("Music Off");
        JMenuItem gameHelp = new JMenuItem("Help");
        JMenuItem about = new JMenuItem("About");
        system.add(quit);
        user.add(setUser);
        set.add(musicOn);
        set.add(musicOff);
        help.add(gameHelp);
        help.add(about);
        menuBar.add(system);
        menuBar.add(user);
        menuBar.add(set);
        menuBar.add(help);
        game.setJMenuBar(menuBar);
        JToolBar toolBar = new JToolBar();
        final JButton b_dealCard = new JButton();
        b_dealCard.setText("fapai");
        final JButton b_chechout = new JButton();
        b_chechout.setText("kaipai");
        JButton b_newGame = new JButton();
        b_newGame.setText("restart");
        toolBar.add(b_dealCard);
        toolBar.add(b_chechout);
        toolBar.add(b_newGame);
        game.getContentPane().add(toolBar, "North");
        game.getCenterPanel().add(game.getComputerCardsPanel(false));
        JLabel cardBack = new JLabel("", new ImageIcon(imageFile + "backSide.png"), 0);
        cardBack.setBounds(300, 210, 130, 180);
        game.getCenterPanel().add(cardBack);
        game.getCenterPanel().add(game.getUserCardsPanel());
        JLabel label = new JLabel();
        label.setText("money:");
        label.setBounds(470, 274, 60, 15);
        game.getCenterPanel().add(label);
        final JTextField T_gameMoney = new JTextField();
        T_gameMoney.setBounds(470, 307, 130, 21);
        T_gameMoney.setText("20");
        game.getCenterPanel().add(T_gameMoney);
        JButton b_moneyAdd = new JButton();
        b_moneyAdd.setText("+");
        b_moneyAdd.setBounds(605, 306, 50, 20);
        game.getCenterPanel().add(b_moneyAdd);
        JButton b_moneySub = new JButton();
        b_moneySub.setText("-");
        b_moneySub.setBounds(665, 306, 50, 20);
        game.getCenterPanel().add(b_moneySub);
        JLabel l_computerName = new JLabel();
        l_computerName.setText("bot");
        l_computerName.setBounds(136, 210, 60, 15);
        game.getCenterPanel().add(l_computerName);
        JLabel l_userName = new JLabel();
        l_userName.setText(gameUser.getUserName());
        l_userName.setBounds(136, 320, 60, 15);
        game.getCenterPanel().add(l_userName);
        JLabel computerIco = new JLabel("", new ImageIcon(imageFile + computerUser.getUserIco()), 0);
        computerIco.setBounds(60, 200, 80, 80);
        game.getCenterPanel().add(computerIco);
        final JLabel userIco = new JLabel("", new ImageIcon(imageFile + gameUser.getUserIco()), 0);
        userIco.setBounds(60, 290, 80, 80);
        game.getCenterPanel().add(userIco);
        final JLabel l_computerMoney = new JLabel();
        l_computerMoney.setText("money:" + computerUser.getUserMoney());
        l_computerMoney.setBounds(136, 235, 60, 15);
        game.getCenterPanel().add(l_computerMoney);
        final JLabel l_userMoney = new JLabel();
        l_userMoney.setText("money:" + gameUser.getUserMoney());
        l_userMoney.setBounds(136, 340, 60, 15);
        game.getCenterPanel().add(l_userMoney);
        final JLabel l_userValue = new JLabel();
        l_userValue.setBounds(470, 375, 60, 15);
        game.getCenterPanel().add(l_userValue);
        final JLabel l_computerValue = new JLabel();
        l_computerValue.setBounds(470, 210, 60, 15);
        game.getCenterPanel().add(l_computerValue);
        final JLabel l_win = new JLabel();
        l_win.setForeground(new Color(255, 128, 64));
        l_win.setFont(new Font("", 1, 26));
        l_win.setText("win");
        l_win.setBounds(470, 220, 33, 44);
        l_win.setVisible(false);
        game.getCenterPanel().add(l_win);
        quit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                System.exit(0);
            }
        });
        setUser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                final JFrame userSetFrame = new JFrame();
                userSetFrame.setSize(400, 300);
                Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
                int left = (screen.width - userSetFrame.getWidth()) / 2;
                int top = (screen.height - userSetFrame.getHeight()) / 2;
                userSetFrame.setLocation(left, top);
                userSetFrame.setLayout((LayoutManager)null);
                userSetFrame.setResizable(false);
                JLabel l_setUserName = new JLabel();
                l_setUserName.setText("username:");
                l_setUserName.setBounds(100, 10, 100, 20);
                JTextField t_userName = new JTextField();
                t_userName.setText(gameUser.getUserName());
                t_userName.setBounds(160, 10, 100, 20);
                JLabel l_setUserMoney = new JLabel();
                l_setUserMoney.setText("usermoney:");
                l_setUserMoney.setBounds(90, 40, 100, 20);
                final JTextField t_userMoney = new JTextField();
                t_userMoney.setText(String.valueOf(gameUser.getUserMoney()));
                t_userMoney.setBounds(160, 40, 100, 20);
                ButtonGroup chooseIco = new ButtonGroup();
                final JRadioButton ico1 = new JRadioButton();
                ico1.setText("tianhe");
                ico1.setBounds(60, 160, 60, 20);
                final JRadioButton ico2 = new JRadioButton();
                ico2.setText("mengyao");
                ico2.setBounds(160, 160, 60, 20);
                final JRadioButton ico3 = new JRadioButton();
                ico3.setText("lingsha");
                ico3.setBounds(245, 160, 60, 20);
                chooseIco.add(ico1);
                chooseIco.add(ico2);
                chooseIco.add(ico3);
                JLabel l_ico1 = new JLabel("", new ImageIcon(GameMain.imageFile + "1.png"), 0);
                JLabel l_ico2 = new JLabel("", new ImageIcon(GameMain.imageFile + "2.png"), 0);
                JLabel l_ico3 = new JLabel("", new ImageIcon(GameMain.imageFile + "3.png"), 0);
                JPanel icoPanel = new JPanel();
                icoPanel.add(l_ico1);
                icoPanel.add(l_ico2);
                icoPanel.add(l_ico3);
                icoPanel.setBounds(30, 70, 300, 85);
                JButton b_setUser = new JButton();
                b_setUser.setBounds(80, 200, 100, 20);
                b_setUser.setText("ok");
                JButton b_setUserCancel = new JButton();
                b_setUserCancel.setBounds(200, 200, 100, 20);
                b_setUserCancel.setText("cancel");
                userSetFrame.add(l_setUserName);
                userSetFrame.add(t_userName);
                userSetFrame.add(l_setUserMoney);
                userSetFrame.add(t_userMoney);
                userSetFrame.add(ico1);
                userSetFrame.add(ico2);
                userSetFrame.add(ico3);
                userSetFrame.add(icoPanel);
                userSetFrame.add(b_setUser);
                userSetFrame.add(b_setUserCancel);
                userSetFrame.setVisible(true);
                b_setUser.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent arg0) {
                        gameUser.setUserMoney(Integer.parseInt(t_userMoney.getText()));
                        if (ico1.isSelected()) {
                            gameUser.setUserIco("1.png");
                        } else if (ico2.isSelected()) {
                            gameUser.setUserIco("2.png");
                        } else if (ico3.isSelected()) {
                            gameUser.setUserIco("3.png");
                        }

                        gameUser.save();
                        l_userMoney.setText("money:" + gameUser.getUserMoney());
                        userIco.setIcon(new ImageIcon(GameMain.imageFile + gameUser.getUserIco()));
                        userSetFrame.setVisible(false);
                    }
                });
                b_setUserCancel.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent arg0) {
                        userSetFrame.setVisible(false);
                    }
                });
            }
        });
        gameHelp.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                String message = "<html><h2>Blackjack rule</h2>";
                /*message = message + "<p>?????????????</p>";
                message = message + "<p>????21??????????21???????</p>";
                message = message + "<p>2-10??????????J,Q,K?10??,A????1??????2?</p>";*/
                message = message + "<p>5 cards maximum for each player</p>";
                //message = message + "<p>??????????21??????,???????????</p>";
                /*message = message + "<p>???????????,???</p>";
                message = message + "<p>?????????21?,???????????2?</p>";*/
                JOptionPane.showMessageDialog(game, message);
            }
        });
        about.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                String message = "<html><h2>Blackjack</h2>";
                message = message + "<p>Author : FeiFei</p>";
                message = message + "<p>E-Mail : feifei@dreammx.com</p></html>";
                JOptionPane.showMessageDialog(game, message);
            }
        });
        musicOn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                game.soundPlay();
                musicOn.setEnabled(false);
                musicOff.setEnabled(true);
            }
        });
        musicOff.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                game.soundStop();
                musicOff.setEnabled(false);
                musicOff.setEnabled(true);
            }
        });
        b_dealCard.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                game.countCardsValue(1);
                if (game.getUserCards().size() < 5 && game.getCardsValue(1) < 21) {
                    game.addCard(1);
                    game.countCardsValue(1);
                    game.getUserCardsPanel().removeAll();
                    game.getUserCardsPanel().updateUI();
                } else {
                    String message;
                    if (game.getUserCards().size() < 5 && game.getCardsValue(1) == 21) {
                        message = "<html><p>?21???????...</p></html>";
                        JOptionPane.showMessageDialog(game, message);
                    } else if (game.getUserCards().size() < 5) {
                        message = "<html><p>???????????21</p><p>???... -_-</p></html>";
                        JOptionPane.showMessageDialog(game, message);
                    } else {
                        message = "<html><p>????5?????????</p></html>";
                        JOptionPane.showMessageDialog(game, message);
                    }
                }

            }
        });
        b_newGame.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                b_dealCard.setEnabled(true);
                b_chechout.setEnabled(true);
                game.gameStart();
                game.getComputerCardsPanel(false).removeAll();
                game.getComputerCardsPanel(false).updateUI();
                game.getUserCardsPanel().removeAll();
                game.getUserCardsPanel().updateUI();
                l_userValue.setText("");
                l_computerValue.setText("");
                l_win.setVisible(false);
            }
        });
        b_chechout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                game.getComputerCardsPanel(false).removeAll();
                game.getComputerCardsPanel(true).updateUI();
                game.countCardsValue(0);
                game.countCardsValue(1);
                b_dealCard.setEnabled(false);
                b_chechout.setEnabled(false);
                l_userValue.setText(String.valueOf(game.getCardsValue(1)));
                l_computerValue.setText(String.valueOf(game.getCardsValue(0)));
                game.setGameMoney(Integer.parseInt(T_gameMoney.getText()));
                if (game.getCardsValue(1) < 21 && game.getCardsValue(0) < game.getCardsValue(1) || game.getCardsValue(1) < 21 && game.getCardsValue(0) > 21) {
                    l_win.setBounds(470, 340, 33, 44);
                    gameUser.setUserMoney(gameUser.getUserMoney() + game.getGameMoney());
                    computerUser.setUserMoney(computerUser.getUserMoney() - game.getGameMoney());
                } else if (game.getCardsValue(0) == 21) {
                    l_win.setBounds(470, 220, 33, 44);
                    computerUser.setUserMoney(computerUser.getUserMoney() + 2 * game.getGameMoney());
                    gameUser.setUserMoney(gameUser.getUserMoney() + game.getGameMoney());
                } else if (game.getCardsValue(1) == 21 && game.getCardsValue(0) != 21) {
                    l_win.setBounds(470, 340, 33, 44);
                    gameUser.setUserMoney(gameUser.getUserMoney() + 2 * game.getGameMoney());
                    computerUser.setUserMoney(computerUser.getUserMoney() - 2 * game.getGameMoney());
                } else {
                    l_win.setBounds(470, 220, 33, 44);
                    computerUser.setUserMoney(computerUser.getUserMoney() + 2 * game.getGameMoney());
                    gameUser.setUserMoney(gameUser.getUserMoney() - game.getGameMoney());
                }

                l_computerMoney.setText(String.valueOf(computerUser.getUserMoney()));
                l_userMoney.setText(String.valueOf(gameUser.getUserMoney()));
                l_win.setVisible(true);
                //gameUser.save();
                //computerUser.save();
            }
        });
        T_gameMoney.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent arg0) {
                int tempMoney = Integer.parseInt(T_gameMoney.getText());
                if (tempMoney < 10) {
                    T_gameMoney.setText("10");
                } else if (tempMoney < gameUser.getUserMoney() && tempMoney < computerUser.getUserMoney()) {
                    game.setGameMoney(tempMoney);
                    T_gameMoney.setText(String.valueOf(tempMoney));
                } else if (tempMoney > gameUser.getUserMoney() || tempMoney > computerUser.getUserMoney()) {
                    T_gameMoney.setText(String.valueOf(Math.min(gameUser.getUserMoney(), computerUser.getUserMoney())));
                }

                game.setGameMoney(Integer.parseInt(T_gameMoney.getText()));
            }
        });
        b_moneyAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                if (Integer.parseInt(T_gameMoney.getText()) + 10 < computerUser.getUserMoney() && Integer.parseInt(T_gameMoney.getText()) + 10 < gameUser.getUserMoney()) {
                    T_gameMoney.setText(String.valueOf(Integer.parseInt(T_gameMoney.getText()) + 10));
                    game.setGameMoney(Integer.parseInt(T_gameMoney.getText()));
                }

            }
        });
        b_moneySub.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                if (Integer.parseInt(T_gameMoney.getText()) - 10 > 0) {
                    T_gameMoney.setText(String.valueOf(Integer.parseInt(T_gameMoney.getText()) - 10));
                } else {
                    T_gameMoney.setText("10");
                }

                game.setGameMoney(Integer.parseInt(T_gameMoney.getText()));
            }
        });
        game.setVisible(true);
    }
}
